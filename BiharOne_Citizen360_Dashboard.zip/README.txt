
BiharOne Citizen Dashboard Demo

Open index.html in any browser.

Deploy:
- Vercel
- Netlify
- Render Static Site
- GitHub Pages

Embed in Liferay:
<iframe src='https://YOUR-URL' width='100%' height='1200' style='border:none'></iframe>
